-- MySQL dump 10.13  Distrib 5.7.43, for Linux (x86_64)
--
-- Host: localhost    Database: skipads
-- ------------------------------------------------------
-- Server version	5.7.43-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bilibili`
--

DROP TABLE IF EXISTS `bilibili`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bilibili` (
  `bv` text NOT NULL,
  `skipparts` json NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `submit` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bilibili`
--

LOCK TABLES `bilibili` WRITE;
/*!40000 ALTER TABLE `bilibili` DISABLE KEYS */;
INSERT INTO `bilibili` VALUES ('sb','[{\"end\": 34, \"start\": 30}, {\"end\": 38, \"start\": 36}]','2024-10-26 14:05:09',NULL),('BV1YC11YgEr9','[{\"end\": 34, \"start\": 30}, {\"end\": 78, \"start\": 45}]','2024-10-26 14:05:09',NULL);
/*!40000 ALTER TABLE `bilibili` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devusers`
--

DROP TABLE IF EXISTS `devusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devusers` (
  `username` text NOT NULL,
  `password` text NOT NULL,
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devusers`
--

LOCK TABLES `devusers` WRITE;
/*!40000 ALTER TABLE `devusers` DISABLE KEYS */;
/*!40000 ALTER TABLE `devusers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `joyfun`
--

DROP TABLE IF EXISTS `joyfun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `joyfun` (
  `joyfunid` text NOT NULL,
  `skipparts` json NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `submit` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `joyfun`
--

LOCK TABLES `joyfun` WRITE;
/*!40000 ALTER TABLE `joyfun` DISABLE KEYS */;
/*!40000 ALTER TABLE `joyfun` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'skipads'
--

--
-- Dumping routines for database 'skipads'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-09  9:20:26
